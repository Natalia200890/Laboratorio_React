import React from 'react';
import './styles.css';
import TaskList from './components/TaskList';

const App = () => {
  return (
    <div className="App">
      <h1 className="app-title">Lista de Tareas</h1>
      <TaskList />
    </div>
  );
};

export default App;
