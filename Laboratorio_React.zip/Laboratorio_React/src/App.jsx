import React, { useState } from 'react';
import TaskList from './TaskList';
import './styles.css';

const App = () => {
  const [userName, setUserName] = useState('John');
  const [taskItems, setTaskItems] = useState([]);

  const addTask = (taskName) => {
    if (taskName.trim() !== '') {
      setTaskItems([...taskItems, { name: taskName, done: false }]);
    }
  };

  const toggleTask = (index) => {
    const updatedTasks = [...taskItems];
    updatedTasks[index].done = !updatedTasks[index].done;
    setTaskItems(updatedTasks);
  };

  const deleteTask = (index) => {
    const updatedTasks = taskItems.filter((_, i) => i !== index);
    setTaskItems(updatedTasks);
  };

  const deleteAllTasks = () => {
    setTaskItems([]);
  };

  return (
    <div className="App">
      <TaskBanner userName={userName} taskItems={taskItems} />
      <TaskForm addTask={addTask} />
      <TaskList
        tasks={taskItems}
        toggleTask={toggleTask}
        deleteTask={deleteTask}
        deleteAllTasks={deleteAllTasks}
      />
    </div>
  );
};

export default App;
