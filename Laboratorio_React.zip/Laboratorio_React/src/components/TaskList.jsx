import React, { useState } from 'react';
import TaskItem from './TaskItem';

const TaskList = () => {
  const [taskItems, setTaskItems] = useState([]);
  const [newTask, setNewTask] = useState('');

  const addTask = () => {
    if (newTask.trim() !== '') {
      setTaskItems([...taskItems, { name: newTask, done: false }]);
      setNewTask('');
    }
  };

  const toggleTask = (index) => {
    const updatedTasks = [...taskItems];
    updatedTasks[index].done = !updatedTasks[index].done;
    setTaskItems(updatedTasks);
  };

  const deleteTask = (index) => {
    const updatedTasks = taskItems.filter((_, i) => i !== index);
    setTaskItems(updatedTasks);
  };

  const deleteAllTasks = () => {
    setTaskItems([]);
  };

  const pendingTasks = taskItems.filter((task) => !task.done).length;
  const completedTasks = taskItems.filter((task) => task.done).length;

  return (
    <div className="task-container">
      <input
        type="text"
        className="task-input"
        placeholder="Nueva tarea..."
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
      />
      <div className="button-group">
        <button className="add-button" onClick={addTask}>
          Agregar Tarea
        </button>
      </div>
      <button className="delete-all-button" onClick={deleteAllTasks} disabled={taskItems.length === 0}>
        Eliminar Todas las Tareas
      </button>
      <div className="task-summary">
        <br></br>
        <p>Pendientes: {pendingTasks}</p>
        <p>Completadas: {completedTasks}</p>
      </div>
      <ul className="task-list">
        {taskItems.map((task, index) => (
          <TaskItem
            key={index}
            task={task}
            index={index}
            toggleTask={toggleTask}
            deleteTask={deleteTask}
          />
        ))}
      </ul>
    </div>
  );
};

export default TaskList;




