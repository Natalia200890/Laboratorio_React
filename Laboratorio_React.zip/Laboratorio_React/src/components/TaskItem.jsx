import React from 'react';

const TaskItem = ({ task, index, toggleTask, deleteTask }) => {
  return (
    <li className={`task-item ${task.done ? 'done' : ''}`}>
       <div className="task-buttons">
      <span  onClick={() => toggleTask(index)}>{task.name}</span>
      </div>
      <div>
        <button className="done-button" onClick={() => toggleTask(index)}>
          Realizada
        </button>
        <button className="delete-button" onClick={() => deleteTask(index)}>
          Eliminar
        </button>
      </div>
    </li>
  );
};

export default TaskItem;
